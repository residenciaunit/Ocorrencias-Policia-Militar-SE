// ARQUIVO: lib/cadastro_rop.dart
// (ESTÁVEL - Guarda o estado da Etapa 2)

import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; 
import 'relatorio_rop.dart';

// Importe TODOS os modelos de dados aqui
import 'arma.dart';
import 'dinheiro.dart';
import 'drogas.dart';
import 'municao.dart';
import 'objeto.dart';
import 'veiculo.dart';
import 'individuo.dart';
import 'policial.dart';

// ignore_for_file: prefer_const_constructors

class CadastroRopScreen extends StatefulWidget {
  const CadastroRopScreen({super.key});

  @override
  State<CadastroRopScreen> createState() => _CadastroRopScreenState();
}

class _CadastroRopScreenState extends State<CadastroRopScreen> {
  // --- DADOS DA ETAPA 1 ---
  final TextEditingController _numAtendimentoController = TextEditingController();
  final TextEditingController _destinoController = TextEditingController();
  final TextEditingController _logradouroController = TextEditingController();
  final TextEditingController _numeroController = TextEditingController();
  final TextEditingController _pontoReferenciaController = TextEditingController();
  final TextEditingController _dataController = TextEditingController();
  final TextEditingController _horaController = TextEditingController();
  String? _selectedRopType;
  String? _selectedCity;
  String? _selectedBairro;
  final Map<String, bool> _toggleStates = {
    'Dinheiro': false,
    'Drogas': false,
    'Armas': false,
    'Veículo': false,
    'Objeto': false,
    'Munição': false,
    'Indivíduo': false,
  };
  final bool _isNextButtonEnabled = true;

  // --- ESTADO DA ETAPA 2 (Guardado aqui) ---
  final TextEditingController _historicoController = TextEditingController();
  final List<Arma> _armasAdicionados = [];
  final List<Dinheiro> _dinheiroAdicionado = [];
  final List<Drogas> _drogasAdicionado = [];
  final List<Municao> _municoesAdicionado = [];
  final List<Objeto> _objetosAdicionado = [];
  final List<Veiculo> _veiculosAdicionado = [];
  final List<Individuo> _individuosAdicionados = [];
  final List<Policial> _policiaisAdicionados = []; 

  // Função para abrir o seletor de data
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        _dataController.text = DateFormat('dd/MM/yyyy').format(picked);
      });
    }
  }

  // Função para abrir o seletor de hora
  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        final now = DateTime.now();
        final dt = DateTime(now.year, now.month, now.day, picked.hour, picked.minute);
        _horaController.text = DateFormat('HH:mm').format(dt);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F2), 
      appBar: AppBar(
        title: const Text('Cadastro ROP'),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              padding: const EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8.0),
                border: Border.all(color: Colors.black, width: 2.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 0),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 50),
                  const Text(
                    'Cadastro ROP',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),

                  // Início do formulário
                  _buildDropdown(
                    label: 'TIPO DO ROP:',
                    value: _selectedRopType,
                    items: ['Contra a pessoa e a vida', 'Trânsito', 'Costumes', 'Auxilio ao público', 'Administração pública', 'Entorpecentes', 'Presos'],
                    onChanged: (value) {
                      setState(() {
                        _selectedRopType = value;
                      });
                    },
                  ),
                  _buildDropdown(
                    label: 'Cidade:',
                    value: _selectedCity,
                    items: ['Aracaju', 'Nossa Senhora do Socorro', 'São Cristóvão'],
                    onChanged: (value) {
                      setState(() {
                        _selectedCity = value;
                      });
                    },
                  ),
                  _buildDropdown(
                    label: 'Bairro:',
                    value: _selectedBairro,
                    items: ['13 de Julho', 'Atalaia', 'Centro'], 
                    onChanged: (value) {
                      setState(() {
                        _selectedBairro = value;
                      });
                    },
                  ),
                  _buildTextField(label: 'Nº de atendimento:', controller: _numAtendimentoController, hint: 'Ex.: 2024-00123456'),
                  _buildTextField(label: 'Destino:', controller: _destinoController, hint: 'Ex.: Comando Geral da PM de Sergipe'),
                  _buildTextField(label: 'Logradouro do fato:', controller: _logradouroController, hint: 'Ex.: Rua Niceu Dantas'),
                  _buildTextField(label: 'Número:', controller: _numeroController, hint: 'Ex.: 100', keyboardType: TextInputType.number),
                  _buildTextField(label: 'Ponto de referência:', controller: _pontoReferenciaController, hint: 'Ex.: Ao lado do Residencial Costa do Atlântico'),
                  _buildDateTimePicker(label: 'Data:', controller: _dataController, onTap: () => _selectDate(context)),
                  _buildDateTimePicker(label: 'Hora:', controller: _horaController, onTap: () => _selectTime(context)),
                  const SizedBox(height: 20),
                  _buildToggleButtons(),
                  const SizedBox(height: 40),

                  ElevatedButton(
                    onPressed: _isNextButtonEnabled
                        ? () {
                            // 1. Coleta dados da Etapa 1
                            final Map<String, String?> dadosEtapa1 = {
                              'ropType': _selectedRopType,
                              'city': _selectedCity,
                              'bairro': _selectedBairro,
                              'numAtendimento': _numAtendimentoController.text,
                              'destino': _destinoController.text,
                              'logradouro': _logradouroController.text,
                              'numero': _numeroController.text,
                              'pontoReferencia': _pontoReferenciaController.text,
                              'data': _dataController.text,
                              'hora': _horaController.text,
                            };

                            // 2. Navega para a Etapa 2
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => RelatorioRopScreen(
                                  toggleStates: _toggleStates,
                                  dadosEtapa1: dadosEtapa1, 
                                  
                                  // Passa as listas (que estão salvas aqui)
                                  historicoController: _historicoController,
                                  policiaisAdicionados: _policiaisAdicionados,
                                  individuosAdicionados: _individuosAdicionados,
                                  armasAdicionados: _armasAdicionados,
                                  dinheiroAdicionado: _dinheiroAdicionado,
                                  drogasAdicionado: _drogasAdicionado,
                                  municoesAdicionado: _municoesAdicionado,
                                  objetosAdicionado: _objetosAdicionado,
                                  veiculosAdicionado: _veiculosAdicionado,
                                ),
                              ),
                            );
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1a73e8),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                      textStyle: const TextStyle(fontSize: 16),
                    ).copyWith(
                      backgroundColor: WidgetStateProperty.resolveWith<Color?>(
                        (Set<WidgetState> states) {
                          if (states.contains(WidgetState.disabled)) {
                            return Colors.grey;
                          }
                          return const Color(0xFF1a73e8);
                        },
                      ),
                    ),
                    child: const Text('Próximo', style: TextStyle(color: Colors.white)),
                  ),
                ],
              ),
            ),

            Positioned(
              top: -10,
              right: 8,
              child: Image.asset(
                'assets/logo-pmse.PNG', 
                width: 90,
                height: 90,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- Widgets Auxiliares ---
  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    String? hint,
    TextInputType? keyboardType,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            decoration: InputDecoration(
              hintText: hint,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateTimePicker({
    required String label,
    required TextEditingController controller,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextFormField(
            controller: controller,
            readOnly: true, 
            onTap: onTap,
            decoration: InputDecoration(
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              suffixIcon: Icon(label == 'Data:' ? Icons.calendar_today : Icons.access_time),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: value,
            items: items.map((String item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Text(item),
              );
            }).toList(),
            onChanged: onChanged,
            decoration: InputDecoration(
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleButtons() {
    return Wrap(
      spacing: 10.0, 
      runSpacing: 10.0, 
      alignment: WrapAlignment.center,
      children: _toggleStates.keys.map((String key) {
        return ChoiceChip(
          label: Text(key),
          selected: _toggleStates[key]!,
          onSelected: (bool selected) {
            setState(() {
              _toggleStates[key] = selected;
            });
          },
          backgroundColor: Colors.red,
          selectedColor: Colors.green,
          labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          shape: const StadiumBorder(), 
          showCheckmark: false,
        );
      }).toList(),
    );
  }
}