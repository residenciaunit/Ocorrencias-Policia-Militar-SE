import 'package:flutter/material.dart';
import 'veiculo.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroVeiculo extends StatefulWidget {
  const DialogCadastroVeiculo({super.key});

  @override
  State<DialogCadastroVeiculo> createState() => _DialogCadastroVeiculoState();
}

class _DialogCadastroVeiculoState extends State<DialogCadastroVeiculo> {
  final TextEditingController _chassiController = TextEditingController();
  final TextEditingController _placaController = TextEditingController();
  String? _selectedCor;
  String? _selectedEspecie;
  String? _selectedModelo;
  String? _selectedTipoVeiculo;
  String _restricaoValue = "nao"; 
  final List<String> _cores = ['-', 'Preto', 'Branco', 'Prata', 'Vermelho', 'Azul', 'Cinza', 'Verde', 'Amarelo', 'Outra'];
  final List<String> _especies = ['-', 'Passageiro', 'Carga', 'Misto', 'Especial', 'Coleção'];
  final List<String> _modelos = ['-', 'Hatch', 'Sedan', 'SUV', 'Pickup', 'Moto', 'Outro'];
  final List<String> _tipos = ['-', 'Automóvel', 'Motocicleta', 'Caminhão', 'Ônibus', 'Utilitário', 'Outro'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Veículo Apreendido'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextField(label: 'Chassi:', controller: _chassiController, hint: 'Ex.: 9BWZZZ377VT004251'),
              _buildTextField(label: 'Placa:', controller: _placaController, hint: 'Ex.: ABC1D23'),
              _buildDropdown(label: 'Cor:', hint: '-', value: _selectedCor, items: _cores, onChanged: (value) { setState(() { _selectedCor = value; }); }),
              _buildDropdown(label: 'Espécie do veículo:', hint: '-', value: _selectedEspecie, items: _especies, onChanged: (value) { setState(() { _selectedEspecie = value; }); }),
              _buildDropdown(label: 'Modelo:', hint: '-', value: _selectedModelo, items: _modelos, onChanged: (value) { setState(() { _selectedModelo = value; }); }),
              _buildDropdown(label: 'Tipo do veículo:', hint: '-', value: _selectedTipoVeiculo, items: _tipos, onChanged: (value) { setState(() { _selectedTipoVeiculo = value; }); }),
              _buildRadioButtons(),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novoVeiculo = Veiculo(
              chassi: _chassiController.text,
              placa: _placaController.text,
              cor: _selectedCor,
              especie: _selectedEspecie,
              modelo: _selectedModelo,
              tipoVeiculo: _selectedTipoVeiculo,
              restricao: _restricaoValue,
            );
            Navigator.of(context).pop(novoVeiculo);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar'), 
        ),
      ],
    );
  }

  Widget _buildRadioButtons() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Restrição:', style: const TextStyle(fontWeight: FontWeight.bold)),
          Row(
            children: [
              Radio<String>(value: 'sim', groupValue: _restricaoValue, onChanged: (value) { setState(() { _restricaoValue = value!; }); },),
              Text('Sim'),
              Radio<String>(value: 'nao', groupValue: _restricaoValue, onChanged: (value) { setState(() { _restricaoValue = value!; }); },),
              Text('Não'),
            ],
          ),
        ],
      ),
    );
  }
  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required String hint, required List<String> items, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10),
        ),
      ),
    );
  }
}