// ARQUIVO: lib/veiculo.dart
// (Define o que é um 'Veículo')

class Veiculo {
  final String? chassi;
  final String? placa;
  final String? cor;
  final String? especie;
  final String? modelo;
  final String? tipoVeiculo;
  final String? restricao; // 'sim' ou 'nao'

  Veiculo({
    this.chassi,
    this.placa,
    this.cor,
    this.especie,
    this.modelo,
    this.tipoVeiculo,
    this.restricao,
  });
}