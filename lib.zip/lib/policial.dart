// ARQUIVO: lib/policial.dart

class Policial {
  final String? matricula;
  final String? nome;
  final String? funcao; // Função na ocorrência

  Policial({
    this.matricula,
    this.nome,
    this.funcao,
  });
}