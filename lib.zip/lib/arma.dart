

class Arma {
  final String? tipo;
  final String? marca;
  final String? modelo;
  final String? numeroSerie;
  final String? qtdMunicoes;
  final String? calibre;
  final String? observacoes;

  Arma({
    this.tipo,
    this.marca,
    this.modelo,
    this.numeroSerie,
    this.qtdMunicoes,
    this.calibre,
    this.observacoes,
  });
}