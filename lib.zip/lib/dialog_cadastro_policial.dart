import 'package:flutter/material.dart';
import 'policial.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroPolicial extends StatefulWidget {
  const DialogCadastroPolicial({super.key});

  @override
  State<DialogCadastroPolicial> createState() => _DialogCadastroPolicialState();
}

class _DialogCadastroPolicialState extends State<DialogCadastroPolicial> {
  final _matriculaController = TextEditingController();
  final _nomeController = TextEditingController();
  String? _selectedFuncao;
  final List<String> _funcoes = ['Comandante', 'Motorista', 'Patrulheiro', 'Apoio'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Adicionar Policial Envolvido'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextField(label: 'Matrícula:', controller: _matriculaController, hint: 'Ex: 12345-6'),
              _buildTextField(label: 'Nome:', controller: _nomeController, hint: 'Nome completo do policial'),
              _buildDropdown(
                label: 'Função na ocorrência:',
                value: _selectedFuncao,
                items: _funcoes,
                hint: 'Selecione a função',
                onChanged: (val) {
                  setState(() => _selectedFuncao = val);
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novoPolicial = Policial(
              matricula: _matriculaController.text,
              nome: _nomeController.text,
              funcao: _selectedFuncao,
            );
            Navigator.of(context).pop(novoPolicial);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar'), 
        ),
      ],
    );
  }

  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required List<String> items, required String hint, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        hint: Text(hint),
        isExpanded: true,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item, overflow: TextOverflow.ellipsis),
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        ),
      ),
    );
  }
}