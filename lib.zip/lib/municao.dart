// ARQUIVO: lib/municao.dart
// (Define o que é uma 'Munição')

class Municao {
  final String? tipo;
  final String? quantidade;
  final String? informacoes;

  Municao({
    this.tipo,
    this.quantidade,
    this.informacoes,
  });
}