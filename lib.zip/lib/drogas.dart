// ARQUIVO: lib/drogas.dart
// (Define o que é um 'Droga')

class Drogas {
  final String? tipo;
  final String? apresentacao;
  final String? quantidade;
  final String? unidade;
  final String? embalagem;

  Drogas({
    this.tipo,
    this.apresentacao,
    this.quantidade,
    this.unidade,
    this.embalagem,
  });
}