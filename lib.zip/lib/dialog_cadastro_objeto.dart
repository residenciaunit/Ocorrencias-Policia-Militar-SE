import 'package:flutter/material.dart';
import 'objeto.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroObjeto extends StatefulWidget {
  const DialogCadastroObjeto({super.key});

  @override
  State<DialogCadastroObjeto> createState() => _DialogCadastroObjetoState();
}

class _DialogCadastroObjetoState extends State<DialogCadastroObjeto> {
  final TextEditingController _imeiController = TextEditingController();
  final TextEditingController _nomeController = TextEditingController();
  final TextEditingController _idRopController = TextEditingController();
  String? _selectedTipo;
  final List<String> _tiposDeObjeto = ['-', 'Celular', 'Notebook', 'Monitor', 'Tablet'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Objeto Custodiado'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDropdown(
                label: 'TIPO DO OBJETO:',
                hint: '-',
                value: _selectedTipo,
                items: _tiposDeObjeto,
                onChanged: (value) {
                  setState(() {
                    _selectedTipo = value;
                  });
                },
              ),
              _buildTextField(label: 'IMEI:', controller: _imeiController, hint: 'Ex. :  012345678901234', keyboardType: TextInputType.number),
              _buildTextField(label: 'Nome do Objeto:', controller: _nomeController, hint: 'Ex.: Celular Samsung A51'),
              _buildTextField(label: 'Identificação do ROP:', controller: _idRopController, hint: 'Ex.: 2024-00123456'),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novoObjeto = Objeto(
              tipo: _selectedTipo,
              imei: _imeiController.text,
              nome: _nomeController.text,
              idRop: _idRopController.text,
            );
            Navigator.of(context).pop(novoObjeto);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar'), 
        ),
      ],
    );
  }

  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required String hint, required List<String> items, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10),
        ),
      ),
    );
  }
}