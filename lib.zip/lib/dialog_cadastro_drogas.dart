import 'package:flutter/material.dart';
import 'drogas.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroDrogas extends StatefulWidget {
  const DialogCadastroDrogas({super.key});

  @override
  State<DialogCadastroDrogas> createState() => _DialogCadastroDrogasState();
}

class _DialogCadastroDrogasState extends State<DialogCadastroDrogas> {
  final TextEditingController _apresentacaoController = TextEditingController();
  final TextEditingController _quantidadeController = TextEditingController();
  final TextEditingController _embalagemController = TextEditingController();
  String? _selectedTipo;
  String? _selectedUnidade;
  final List<String> _tiposDeDroga = ['Maconha', 'Cocaína', 'Crack', 'LSD', 'Ecstasy', 'Outros'];
  final List<String> _unidades = ['gramas (g)', 'quilogramas (kg)', 'unidades (un)'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Cadastro de Drogas'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDropdown(
                label: 'Tipo:',
                hint: 'Selecione o tipo',
                value: _selectedTipo,
                items: _tiposDeDroga,
                onChanged: (value) {
                  setState(() {
                    _selectedTipo = value;
                  });
                },
              ),
              _buildTextField(label: 'Apresentação:', controller: _apresentacaoController, hint: 'Ex.: tablete, pó, pedra'),
              _buildTextField(label: 'Quantidade:', controller: _quantidadeController, hint: 'Ex.: 10', keyboardType: TextInputType.number),
              _buildDropdown(
                label: 'Unidade:',
                hint: 'Selecione a unidade',
                value: _selectedUnidade,
                items: _unidades,
                onChanged: (value) {
                  setState(() {
                    _selectedUnidade = value;
                  });
                },
              ),
               _buildTextField(label: 'Embalagem:', controller: _embalagemController, hint: 'Ex.: plástica, papel alumínio'),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novaDroga = Drogas(
              tipo: _selectedTipo,
              apresentacao: _apresentacaoController.text,
              quantidade: _quantidadeController.text,
              unidade: _selectedUnidade,
              embalagem: _embalagemController.text
            );
            Navigator.of(context).pop(novaDroga);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar'), 
        ),
      ],
    );
  }

  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required String hint, required List<String> items, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10),
        ),
      ),
    );
  }
}