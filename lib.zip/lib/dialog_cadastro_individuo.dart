import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'individuo.dart'; 
// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

class DialogCadastroIndividuo extends StatefulWidget {
  const DialogCadastroIndividuo({super.key});

  @override
  State<DialogCadastroIndividuo> createState() => _DialogCadastroIndividuoState();
}

class _DialogCadastroIndividuoState extends State<DialogCadastroIndividuo> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _nomeController = TextEditingController();
  final _apelidoController = TextEditingController();
  final _cpfController = TextEditingController();
  final _rgController = TextEditingController();
  final _dataNascimentoController = TextEditingController();
  final _nacionalidadeController = TextEditingController(text: 'Brasileira');
  final _profissaoController = TextEditingController();
  final _nomeMaeController = TextEditingController();
  final _nomePaiController = TextEditingController();
  final _emailController = TextEditingController();
  final _telefoneController = TextEditingController();
  final _cepController = TextEditingController();
  final _logradouroController = TextEditingController();
  final _numeroController = TextEditingController();
  final _complementoController = TextEditingController();
  final _historicoController = TextEditingController();
  final _cpfMask = MaskTextInputFormatter(mask: '###.###.###-##', filter: {"#": RegExp(r'[0-9]')});
  final _cepMask = MaskTextInputFormatter(mask: '#####-###', filter: {"#": RegExp(r'[0-9]')});
  final _telefoneMask = MaskTextInputFormatter(mask: '(##) #####-####', filter: {"#": RegExp(r'[0-9]')});
  String? _selectedSexo;
  String? _selectedCidade;
  String? _selectedBairro;
  String? _selectedEnvolvimento;
  String? _selectedDetencao;
  String _feridoValue = "false";
  String _algemaValue = "false";
  final Map<String, List<String>> _bairrosPorCidade = {
    "Aracaju": ["Atalaia", "Coroa do Meio", "Farolândia", "Aruana", "Jardins", "Salgado Filho", "São José", "Suíssa", "Centro", "13 de Julho", "Getúlio Vargas", "Cirurgia", "Pereira Lobo", "Dezoito do Forte", "Novo Paraíso", "Luzia", "Olaria", "Palestina", "Bugio", "Industrial", "Cidade Nova", "América", "Capucho", "Siqueira Campos", "São Conrado", "Jabotiana", "Santa Maria", "Aeroporto", "Porto Dantas", "Grageru", "Inácio Barbosa", "Marivan", "Ponto Novo", "Lamarão", "José Conrado de Araújo"],
    "Itabaiana": ["Anízio Amancio de Oliveira", "Área Rural de Itabaiana", "Bananeiras", "Centro", "Doutor José Milton Machado", "Mamede Paes Mendonça", "Marcela", "Marianga", "Miguel Teles de Mendonça", "Oviedo Teixeira", "Porto", "Queimadas", "Riacho Doce", "Rotary Club de Itabaiana", "São Cristóvão", "Serrano"],
    "Lagarto": ["Centro"],
    "Nossa Senhora do Socorro": ["Albano Franco", "Boa Viagem", "Castelo", "Centro Histórico", "Fernando Collor", "Guajará", "Itacanema", "Jardim", "João Alves", "Mangabeira", "Marcos Freire I", "Marcos Freire II", "Marcos Freire III", "Novo Horizonte", "Pai André", "Palestina de Dentro", "Palestina de Fora", "Parque dos Faróis", "Piabeta", "Porto Grande", "Santa Cecília", "Santa Inês", "Santo Inácio", "São Brás", "Sobrado", "Taboca", "Taiçoca de Dentro", "Taiçoca de Fora"],
    "São Cristóvão": ["Centro", "Rosa Elze"],
    "Estância": ["Alagoas", "Centro", "Cidade Nova"],
    "Propriá": ["Centro"],
    "Tobias Barreto": ["Centro"],
    "Itaporanga D'Ajuda": ["Centro"]
  };
  List<String> _cidades = [];
  List<String> _bairros = [];


  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this); 
    _cidades = _bairrosPorCidade.keys.toList()..sort();
  }
   
  @override
  void dispose() {
    _tabController.dispose();
    _nomeController.dispose();
    _apelidoController.dispose();
    _cpfController.dispose();
    _rgController.dispose();
    _dataNascimentoController.dispose();
    _nacionalidadeController.dispose();
    _profissaoController.dispose();
    _nomeMaeController.dispose();
    _nomePaiController.dispose();
    _emailController.dispose();
    _telefoneController.dispose();
    _cepController.dispose();
    _logradouroController.dispose();
    _numeroController.dispose();
    _complementoController.dispose();
    _historicoController.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _dataNascimentoController.text = DateFormat('dd/MM/yyyy').format(picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Cadastro de Indivíduo'),
      content: SizedBox(
        width: MediaQuery.of(context).size.width * 0.9,
        height: MediaQuery.of(context).size.height * 0.7,
        child: Column(
          children: [
            TabBar(
              controller: _tabController,
              isScrollable: true,
              labelColor: Theme.of(context).primaryColor,
              unselectedLabelColor: Colors.grey,
              tabs: [
                Tab(text: 'Identificação'),
                Tab(text: 'Endereço'),
                Tab(text: 'Envolvimento'),
              ],
            ),
            
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildIdentificacaoPessoal(),
                  _buildEndereco(),
                  _buildEnvolvimento(),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novoIndividuo = Individuo(
              nome: _nomeController.text,
              apelido: _apelidoController.text,
              cpf: _cpfController.text,
              rg: _rgController.text,
              dataNascimento: _dataNascimentoController.text,
              sexo: _selectedSexo,
              nacionalidade: _nacionalidadeController.text,
              profissao: _profissaoController.text,
              nomeMae: _nomeMaeController.text,
              nomePai: _nomePaiController.text,
              email: _emailController.text,
              telefone: _telefoneController.text,
              cep: _cepController.text,
              logradouro: _logradouroController.text,
              numero: _numeroController.text,
              complemento: _complementoController.text,
              cidade: _selectedCidade,
              bairro: _selectedBairro,
              tipoEnvolvimento: _selectedEnvolvimento,
              tipoDetencao: _selectedDetencao,
              ferido: _feridoValue,
              houveAlgema: _algemaValue,
              historico: _historicoController.text,
            );
            Navigator.of(context).pop(novoIndividuo);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar Indivíduo'),
        ),
      ],
    );
  }

  // ... (Todas as funções _build... (Abas e widgets auxiliares) não mudam) ...
  Widget _buildIdentificacaoPessoal() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTextField(label: 'Nome Completo:', controller: _nomeController, hint: 'Nome completo do indivíduo'),
          _buildTextField(label: 'Apelido:', controller: _apelidoController, hint: 'Apelido, se houver'),
          _buildTextField(label: 'CPF:', controller: _cpfController, hint: '000.000.000-00', formatter: _cpfMask, keyboardType: TextInputType.number),
          _buildTextField(label: 'RG:', controller: _rgController, hint: 'Número do RG'),
          _buildDateField(label: 'Data de Nascimento:', controller: _dataNascimentoController, onTap: () => _selectDate(context)),
          _buildDropdown(
            label: 'Sexo:',
            value: _selectedSexo,
            items: ['Masculino', 'Feminino', 'Não informado'],
            hint: 'Selecione...',
            onChanged: (val) {
              setState(() => _selectedSexo = val);
            },
          ),
          _buildTextField(label: 'Nacionalidade:', controller: _nacionalidadeController),
          _buildTextField(label: 'Profissão:', controller: _profissaoController, hint: 'Profissão do indivíduo'),
          _buildTextField(label: 'Nome da Mãe:', controller: _nomeMaeController, hint: 'Nome completo da mãe'),
          _buildTextField(label: 'Nome do Pai:', controller: _nomePaiController, hint: 'Nome completo do pai'),
          _buildTextField(label: 'Email:', controller: _emailController, hint: 'email@exemplo.com', keyboardType: TextInputType.emailAddress),
          _buildTextField(label: 'Telefone:', controller: _telefoneController, hint: '(79) 99999-9999', formatter: _telefoneMask, keyboardType: TextInputType.phone),
        ],
      ),
    );
  }
  Widget _buildEndereco() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTextField(label: 'CEP:', controller: _cepController, hint: '00000-000', formatter: _cepMask, keyboardType: TextInputType.number),
          _buildTextField(label: 'Logradouro:', controller: _logradouroController, hint: 'Rua, Avenida, etc.'),
          _buildTextField(label: 'Número:', controller: _numeroController, hint: 'Ex: 123', keyboardType: TextInputType.number),
          _buildTextField(label: 'Complemento:', controller: _complementoController, hint: 'Apto, Bloco, Casa, etc.'),
          _buildDropdown(
            label: 'Cidade:',
            value: _selectedCidade,
            items: _cidades,
            hint: 'Selecione a Cidade',
            onChanged: (val) {
              setState(() {
                _selectedCidade = val;
                _selectedBairro = null; 
                _bairros = _bairrosPorCidade[val] ?? [];
                _bairros.sort();
              });
            },
          ),
          _buildDropdown(
            label: 'Bairro:',
            value: _selectedBairro,
            items: _bairros,
            hint: 'Selecione o Bairro',
            onChanged: (val) {
              setState(() => _selectedBairro = val);
            },
          ),
        ],
      ),
    );
  }
  Widget _buildEnvolvimento() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDropdown(
            label: 'Tipo de Envolvimento:',
            value: _selectedEnvolvimento,
            items: ['Autor', 'Vítima', 'Testemunha', 'Suspeito'],
            hint: 'Selecione...',
            onChanged: (val) {
              setState(() => _selectedEnvolvimento = val);
            },
          ),
          _buildDropdown(
            label: 'Tipo de Detenção:',
            value: _selectedDetencao,
            items: ['Não se aplica', 'Flagrante', 'Mandado de Prisão'],
            hint: 'Não se aplica',
            onChanged: (val) {
              setState(() => _selectedDetencao = val);
            },
          ),
          _buildRadioGroup(
            label: 'Ferido?',
            groupValue: _feridoValue,
            onChanged: (val) {
              setState(() => _feridoValue = val ?? 'false');
            },
          ),
          _buildRadioGroup(
            label: 'Houve uso de algema?',
            groupValue: _algemaValue,
            onChanged: (val) {
              setState(() => _algemaValue = val ?? 'false');
            },
          ),
          _buildDropdown(label: 'Natureza da Ocorrência (Primária):', value: null, items: [], hint: 'Selecione a Natureza', onChanged: (val){}),
          _buildDropdown(label: 'Subtipo da Natureza (Primária):', value: null, items: [], hint: 'Selecione o Subtipo', onChanged: (val){}),
          _buildTextField(
            label: 'Histórico/Observações do Indivíduo:',
            controller: _historicoController,
            hint: 'Descreva informações relevantes...',
            maxLines: 4
          ),
        ],
      ),
    );
  }
  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1, TextInputFormatter? formatter}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        inputFormatters: formatter != null ? [formatter] : [],
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        ),
      ),
    );
  }
  Widget _buildDateField({required String label, required TextEditingController controller, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        readOnly: true,
        onTap: onTap,
        decoration: InputDecoration(
          labelText: label,
          hintText: 'dd/MM/yyyy',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          suffixIcon: Icon(Icons.calendar_today),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required List<String> items, required String hint, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        hint: Text(hint),
        isExpanded: true,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item, overflow: TextOverflow.ellipsis), 
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        ),
      ),
    );
  }
  Widget _buildRadioGroup({required String label, required String groupValue, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Row(
            children: [
              Radio<String>(value: 'true', groupValue: groupValue, onChanged: onChanged),
              Text('Sim'),
              Radio<String>(value: 'false', groupValue: groupValue, onChanged: onChanged),
              Text('Não'),
            ],
          ),
        ],
      ),
    );
  }
}