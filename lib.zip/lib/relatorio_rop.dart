// ARQUIVO: lib/relatorio_rop.dart
// (VERSÃO ESTÁVEL - Sem Edit/Delete, com cards simples)

import 'package:flutter/material.dart';
// Importe todos os modelos
import 'arma.dart'; 
import 'dinheiro.dart'; 
import 'drogas.dart';
import 'municao.dart';
import 'objeto.dart';
import 'veiculo.dart'; 
import 'individuo.dart'; 
import 'policial.dart'; 
// Importe todos os dialogs/telas
import 'dialog_cadastro_arma.dart'; 
import 'dialog_cadastro_dinheiro.dart';
import 'dialog_cadastro_drogas.dart';
import 'dialog_cadastro_municao.dart';
import 'dialog_cadastro_objeto.dart';
import 'dialog_cadastro_veiculo.dart';
import 'dialog_cadastro_individuo.dart'; 
import 'dialog_cadastro_policial.dart';
import 'finalizacao_rop_screen.dart';

// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

class RelatorioRopScreen extends StatefulWidget {
  final Map<String, bool> toggleStates;
  final Map<String, String?> dadosEtapa1; 
  
  final TextEditingController historicoController;
  final List<Arma> armasAdicionados;
  final List<Dinheiro> dinheiroAdicionado;
  final List<Drogas> drogasAdicionado;
  final List<Municao> municoesAdicionado;
  final List<Objeto> objetosAdicionado;
  final List<Veiculo> veiculosAdicionado;
  final List<Individuo> individuosAdicionados;
  final List<Policial> policiaisAdicionados;

  const RelatorioRopScreen({
    super.key,
    required this.toggleStates,
    required this.dadosEtapa1, 
    required this.historicoController,
    required this.armasAdicionados,
    required this.dinheiroAdicionado,
    required this.drogasAdicionado,
    required this.municoesAdicionado,
    required this.objetosAdicionado,
    required this.veiculosAdicionado,
    required this.individuosAdicionados,
    required this.policiaisAdicionados,
  });

  @override
  State<RelatorioRopScreen> createState() => _RelatorioRopScreenState();
}

class _RelatorioRopScreenState extends State<RelatorioRopScreen> {

  final Map<String, String> _sectionTitles = {
    'Indivíduo': 'Indivíduos Envolvidos',
    'Armas': 'Armas de Fogo',
    'Munição': 'Munições',
    'Dinheiro': 'Dinheiro',
    'Drogas': 'Drogas',
    'Veículo': 'Veículos',
    'Objeto': 'Objetos',
  };

  // --- Funções de Abertura de Dialog (Simplificadas - Apenas Adicionar) ---
  
  Future<void> _abrirDialogCadastroArma() async {
    final Arma? armaRetornada = await showDialog<Arma>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroArma(); // Não passa 'armaExistente'
      },
    );
    if (armaRetornada != null && mounted) {
      setState(() {
        widget.armasAdicionados.add(armaRetornada); // Apenas Adição
      });
    }
  }

  Future<void> _abrirDialogCadastroDinheiro() async {
    final Dinheiro? dinheiroRetornado = await showDialog<Dinheiro>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroDinheiro();
      },
    );
    if (dinheiroRetornado != null && mounted) {
      setState(() {
        widget.dinheiroAdicionado.add(dinheiroRetornado);
      });
    }
  }

  Future<void> _abrirDialogCadastroDrogas() async {
    final Drogas? drogaRetornada = await showDialog<Drogas>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroDrogas();
      },
    );
    if (drogaRetornada != null && mounted) {
      setState(() {
        widget.drogasAdicionado.add(drogaRetornada);
      });
    }
  }

  Future<void> _abrirDialogCadastroMunicao() async {
    final Municao? municaoRetornada = await showDialog<Municao>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroMunicao();
      },
    );
     if (municaoRetornada != null && mounted) {
      setState(() {
          widget.municoesAdicionado.add(municaoRetornada);
      });
    }
  }

  Future<void> _abrirDialogCadastroObjeto() async {
    final Objeto? objetoRetornado = await showDialog<Objeto>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroObjeto();
      },
    );
    if (objetoRetornado != null && mounted) {
      setState(() {
          widget.objetosAdicionado.add(objetoRetornado);
      });
    }
  }

  Future<void> _abrirDialogCadastroVeiculo() async {
    final Veiculo? veiculoRetornado = await showDialog<Veiculo>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroVeiculo();
      },
    );
    if (veiculoRetornado != null && mounted) {
      setState(() {
          widget.veiculosAdicionado.add(veiculoRetornado);
      });
    }
  }

  Future<void> _abrirDialogCadastroIndividuo() async {
    final Individuo? individuoRetornado = await showDialog<Individuo>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return DialogCadastroIndividuo();
      },
    );
    if (individuoRetornado != null && mounted) {
      setState(() {
          widget.individuosAdicionados.add(individuoRetornado);
      });
    }
  }

  Future<void> _abrirDialogCadastroPolicial() async {
    final Policial? policialRetornado = await showDialog<Policial>(
      context: context,
      barrierDismissible: false, 
      builder: (BuildContext context) {
        return DialogCadastroPolicial();
      },
    );
    if (policialRetornado != null && mounted) {
      setState(() {
          widget.policiaisAdicionados.add(policialRetornado);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F2),
      appBar: AppBar(
        title: const Text('Relatório de Ocorrência'),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
        automaticallyImplyLeading: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              padding: const EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8.0),
                border: Border.all(color: Colors.black, width: 2.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 0),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 50),
                  const Text(
                    'Relatório de Ocorrência Policial',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  _buildResumoRop(),
                  const SizedBox(height: 20),
                  _buildPoliciaisEnvolvidosSection(),
                  const SizedBox(height: 20),
                  
                  ..._sectionTitles.keys.map((key) {
                    if (widget.toggleStates[key] ?? false) {
                      int badgeCount = 0;
                      if (key == 'Indivíduo') badgeCount = widget.individuosAdicionados.length; 
                      if (key == 'Armas') badgeCount = widget.armasAdicionados.length;
                      if (key == 'Dinheiro') badgeCount = widget.dinheiroAdicionado.length;
                      if (key == 'Drogas') badgeCount = widget.drogasAdicionado.length;
                      if (key == 'Munição') badgeCount = widget.municoesAdicionado.length;
                      if (key == 'Objeto') badgeCount = widget.objetosAdicionado.length;
                      if (key == 'Veículo') badgeCount = widget.veiculosAdicionado.length;

                      return _buildAccordionItem(
                        key: key, 
                        title: _sectionTitles[key]!,
                        badgeCount: badgeCount,
                      );
                    }
                    return SizedBox.shrink();
                  }),

                  const SizedBox(height: 20),
                  _buildHistoricoField(), 
                  const SizedBox(height: 40),
                  _buildActionButtons(), 
                ],
              ),
            ),
            Positioned(
              top: -10,
              right: 8,
              child: Image.asset(
                'assets/logo-pmse.PNG',
                width: 90,
                height: 90,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- Widgets Auxiliares ---

  Widget _buildResumoRop() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('TIPO DO ROP:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              Text(widget.dadosEtapa1['ropType'] ?? 'Não informado'),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('NÚMERO:', style: TextStyle(fontWeight: FontWeight.bold)),
              Text(widget.dadosEtapa1['numAtendimento'] ?? 'Não informado'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPoliciaisEnvolvidosSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, 
      children: [
        Text(
          'Policiais Envolvidos',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Divider(height: 20, thickness: 1),
        
        if (widget.policiaisAdicionados.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0, top: 5.0),
            child: Text('Nenhum policial adicionado.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey[600])),
          ),

        ...widget.policiaisAdicionados.map((policial) {
          return _buildPolicialCard(policial);
        }),

        const SizedBox(height: 10),
        
        ElevatedButton.icon(
          icon: const Icon(Icons.add, size: 18),
          label: Text('Adicionar Policial'),
          onPressed: _abrirDialogCadastroPolicial, 
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green, 
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ),
        Divider(height: 30, thickness: 1), 
      ],
    );
  }

  Widget _buildAccordionItem({
    required String key, 
    required String title,
    required int badgeCount,
  }) {
    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 10),
      child: ExpansionTile(
        key: PageStorageKey(key),
        initiallyExpanded: badgeCount > 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              child: Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            Chip(
              label: Text('$badgeCount',
                  style: const TextStyle(color: Colors.white)),
              backgroundColor: badgeCount > 0 ? Color(0xFF1a73e8) : Colors.grey,
              padding: EdgeInsets.zero,
              labelPadding: const EdgeInsets.symmetric(horizontal: 8),
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: _buildAccordionContent(key),
          )
        ],
      ),
    );
  }

  // --- Roteador de Conteúdo ---
  Widget _buildAccordionContent(String key) {
    if (key == 'Armas') {
      return _buildArmasContent();
    }
    if (key == 'Dinheiro') {
      return _buildDinheiroContent();
    }
    if (key == 'Drogas') {
      return _buildDrogasContent();
    }
    if (key == 'Munição') {
      return _buildMunicaoContent();
    }
    if (key == 'Objeto') {
      return _buildObjetoContent();
    }
    if (key == 'Veículo') {
      return _buildVeiculoContent();
    }
    if (key == 'Indivíduo') {
      return _buildIndividuosContent();
    }
    return _buildGenericEmptyContent(key);
  }

  // ---
  // --- SEÇÃO DE CONTEÚDO DO ACORDEÃO (Simplificados)
  // ---

  Widget _buildIndividuosContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.individuosAdicionados.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhum indivíduo cadastrado.', textAlign: TextAlign.center),
          ),
        ...widget.individuosAdicionados.map((individuo) {
          return _buildIndividuoCard(individuo); // Card Simples
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Indivíduo',
          onPressed: _abrirDialogCadastroIndividuo, // Versão simples
        ),
      ],
    );
  }


  Widget _buildArmasContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.armasAdicionados.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhuma arma cadastrada.', textAlign: TextAlign.center),
          ),
        ...widget.armasAdicionados.map((arma) {
          return _buildArmaCard(arma);
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Arma',
          onPressed: _abrirDialogCadastroArma,
        ),
      ],
    );
  }

  Widget _buildDinheiroContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.dinheiroAdicionado.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhum valor cadastrado.', textAlign: TextAlign.center),
          ),
        ...widget.dinheiroAdicionado.map((dinheiro) {
          return _buildDinheiroCard(dinheiro);
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Dinheiro',
          onPressed: _abrirDialogCadastroDinheiro,
        ),
      ],
    );
  }

  Widget _buildDrogasContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.drogasAdicionado.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhuma droga cadastrada.', textAlign: TextAlign.center),
          ),
        ...widget.drogasAdicionado.map((droga) {
          return _buildDrogaCard(droga);
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Droga',
          onPressed: _abrirDialogCadastroDrogas,
        ),
      ],
    );
  }

  Widget _buildMunicaoContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.municoesAdicionado.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhuma munição cadastrada.', textAlign: TextAlign.center),
          ),
        ...widget.municoesAdicionado.map((municao) {
          return _buildMunicaoCard(municao);
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Munição',
          onPressed: _abrirDialogCadastroMunicao,
        ),
      ],
    );
  }

  Widget _buildObjetoContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.objetosAdicionado.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhum objeto cadastrado.', textAlign: TextAlign.center),
          ),
        ...widget.objetosAdicionado.map((objeto) {
          return _buildObjetoCard(objeto);
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Objeto',
          onPressed: _abrirDialogCadastroObjeto,
        ),
      ],
    );
  }

  Widget _buildVeiculoContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (widget.veiculosAdicionado.isEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 10.0),
            child: Text('Nenhum veículo cadastrado.', textAlign: TextAlign.center),
          ),
        ...widget.veiculosAdicionado.map((veiculo) {
          return _buildVeiculoCard(veiculo);
        }),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar Veículo',
          onPressed: _abrirDialogCadastroVeiculo,
        ),
      ],
    );
  }

  // ---
  // --- SEÇÃO DE CARDS (VOLTARAM A SER SIMPLES E ESTÁVEIS)
  // ---

  Widget _buildPolicialCard(Policial policial) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style.copyWith(fontSize: 14),
            children: [
              const TextSpan(
                  text: 'Nome: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${policial.nome ?? "Não informado"}\n'),
              const TextSpan(
                  text: 'Matrícula: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${policial.matricula ?? "Não informado"}\n'),
              const TextSpan(
                  text: 'Função: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: policial.funcao ?? "Não informado"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIndividuoCard(Individuo individuo) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style.copyWith(fontSize: 14),
            children: [
              const TextSpan(
                  text: 'Nome: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${individuo.nome ?? "Não informado"}\n'),
              const TextSpan(
                  text: 'CPF: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${individuo.cpf ?? "Não informado"}\n'),
              const TextSpan(
                  text: 'Envolvimento: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: individuo.tipoEnvolvimento ?? "Não informado"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildArmaCard(Arma arma) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                  text: 'Tipo: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${arma.tipo ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Marca: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${arma.marca ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Modelo: ',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: arma.modelo ?? "Não informado"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDinheiroCard(Dinheiro dinheiro) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                  text: 'Valor: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${dinheiro.valor ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Moeda: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: dinheiro.moeda ?? "Não informado"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrogaCard(Drogas droga) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                  text: 'Tipo: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${droga.tipo ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Qtd: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${droga.quantidade ?? "-"} ${droga.unidade ?? ""}\n'),
              TextSpan(
                  text: 'Apresentação: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: droga.apresentacao ?? "Não informado"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMunicaoCard(Municao municao) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                  text: 'Tipo: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${municao.tipo ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Qtd: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: municao.quantidade ?? "-"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildObjetoCard(Objeto objeto) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                  text: 'Tipo: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${objeto.tipo ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Nome: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${objeto.nome ?? "Não informado"}\n'),
              TextSpan(
                  text: 'IMEI: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: objeto.imei ?? "-"),
            ],
          ),
        ),
      ),
    );
  }

   Widget _buildVeiculoCard(Veiculo veiculo) {
    return Card(
      elevation: 2,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style,
            children: [
              TextSpan(
                  text: 'Placa: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${veiculo.placa ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Modelo: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: '${veiculo.modelo ?? "Não informado"}\n'),
              TextSpan(
                  text: 'Cor: ', style: TextStyle(fontWeight: FontWeight.bold)),
              TextSpan(text: veiculo.cor ?? "-"),
            ],
          ),
        ),
      ),
    );
  }

  // --- Widgets Genéricos e de Ação ---

  Widget _buildAddButton({required String label, required VoidCallback onPressed}) {
    return ElevatedButton.icon(
      icon: const Icon(Icons.add, size: 18),
      label: Text(label),
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
        ),
      ),
    );
  }

  Widget _buildGenericEmptyContent(String key) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Nenhum(a) $key cadastrado(a).', textAlign: TextAlign.center),
        const SizedBox(height: 10),
        _buildAddButton(
          label: 'Adicionar $key',
          onPressed: () {
             ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Funcionalidade de "$key" não implementada.'))
            );
          },
        ),
      ],
    );
  }

  Widget _buildHistoricoField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Histórico da Ocorrência:',
            style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextFormField(
          controller: widget.historicoController, // Usa o controller da Etapa 1
          maxLines: 10,
          minLines: 5,
          decoration: InputDecoration(
            hintText:
                'Descreva aqui o histórico completo e detalhado da ocorrência...',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              Navigator.of(context).pop(); // Volta para a Etapa 1
            },
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              side: BorderSide(color: Colors.grey[700]!),
              foregroundColor: Colors.grey[700],
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            child: const Text('Voltar', style: TextStyle(fontSize: 16)),
          ),
        ),
        const SizedBox(width: 20),
        Expanded(
          child: ElevatedButton(
            onPressed: () {
              // Navega para a Etapa 3 (Finalização)
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FinalizacaoRopScreen(
                    dadosEtapa1: widget.dadosEtapa1,
                    historicoEtapa2: widget.historicoController.text,
                    policiais: widget.policiaisAdicionados,
                    individuos: widget.individuosAdicionados,
                    armas: widget.armasAdicionados,
                    municoes: widget.municoesAdicionado,
                    dinheiro: widget.dinheiroAdicionado,
                    drogas: widget.drogasAdicionado,
                    veiculos: widget.veiculosAdicionado,
                    objetos: widget.objetosAdicionado,
                  ),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1a73e8),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(6),
              ),
            ),
            child: const Text('Revisar e Finalizar', style: TextStyle(fontSize: 16), textAlign: TextAlign.center,),
          ),
        ),
      ],
    );
  }
}