// ARQUIVO: lib/objeto.dart
// (Define o que é um 'Objeto')

class Objeto {
  final String? tipo;
  final String? imei;
  final String? nome;
  final String? idRop; // Identificação do ROP

  Objeto({
    this.tipo,
    this.imei,
    this.nome,
    this.idRop,
  });
}