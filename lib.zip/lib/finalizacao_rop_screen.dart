// ARQUIVO: lib/finalizacao_rop_screen.dart
// (ATUALIZADO para mostrar TODOS os detalhes e ocultar seções vazias)

import 'package:flutter/material.dart';
// Importe todos os seus modelos de dados
import 'arma.dart';
import 'dinheiro.dart';
import 'drogas.dart';
import 'municao.dart';
import 'objeto.dart';
import 'veiculo.dart';
import 'individuo.dart';
import 'policial.dart';

// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

class FinalizacaoRopScreen extends StatefulWidget {
  // Recebe TODOS os dados das etapas anteriores
  final Map<String, String?> dadosEtapa1;
  final String historicoEtapa2;
  final List<Policial> policiais;
  final List<Individuo> individuos;
  final List<Arma> armas;
  final List<Municao> municoes;
  final List<Dinheiro> dinheiro;
  final List<Drogas> drogas;
  final List<Veiculo> veiculos;
  final List<Objeto> objetos;

  const FinalizacaoRopScreen({
    super.key,
    required this.dadosEtapa1,
    required this.historicoEtapa2,
    required this.policiais,
    required this.individuos,
    required this.armas,
    required this.municoes,
    required this.dinheiro,
    required this.drogas,
    required this.veiculos,
    required this.objetos,
  });

  @override
  State<FinalizacaoRopScreen> createState() => _FinalizacaoRopScreenState();
}

class _FinalizacaoRopScreenState extends State<FinalizacaoRopScreen> {
  String? _selectedDestinatario;
  bool _termsAccepted = false;

  final List<String> _destinatarios = [
    '1ª Delegacia Metropolitana (1ª DM)',
    '2ª Delegacia Metropolitana (2ª DM)',
    '3ª Delegacia Metropolitana (3ª DM)',
    'Delegacia de Turismo (DETUR)',
    '1º Batalhão de Polícia Militar (1º BPM)',
    'Companhia de Polícia de Trânsito (CPTran)',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Revisão e Finalização'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- 1. Resumo da Etapa 1 ---
            _buildResumoEtapa1(),
            SizedBox(height: 16),

            // --- 2. Resumo da Etapa 2 ---
            _buildResumoEtapa2(),
            SizedBox(height: 24),

            // --- 3. Campos da Etapa 3 ---
            _buildDropdown(
              label: 'Destinatário Final (Delegacia/Batalhão):',
              value: _selectedDestinatario,
              items: _destinatarios,
              hint: 'Selecione o destinatário...',
              onChanged: (val) {
                setState(() => _selectedDestinatario = val);
              },
            ),
            SizedBox(height: 16),
            CheckboxListTile(
              title: Text(
                'Confirmo que todas as informações preenchidas são verdadeiras e precisas.',
                style: TextStyle(fontSize: 14),
              ),
              value: _termsAccepted,
              onChanged: (val) {
                setState(() => _termsAccepted = val ?? false);
              },
              controlAffinity: ListTileControlAffinity.leading, // Checkbox na esquerda
              contentPadding: EdgeInsets.zero,
            ),
            SizedBox(height: 24),

            // --- 4. Ações ---
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  // ---
  // --- Widgets Auxiliares de Resumo (ATUALIZADOS)
  // ---

  // Constrói uma linha "Label: Valor" apenas se o valor não for vazio
  Widget _buildLinhaInfo(String label, String? value) {
    if (value == null || value.isEmpty || value == '-') {
      return SizedBox.shrink(); // Não mostra nada se o valor estiver vazio ou for '-'
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ', style: TextStyle(fontWeight: FontWeight.bold)),
          Expanded(
            child: Text(value, textAlign: TextAlign.right),
          ),
        ],
      ),
    );
  }

  // Constrói um card de resumo para um item
  Widget _buildItemCard(List<Widget> children) {
    return Card(
      elevation: 1,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 8.0),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: children,
        ),
      ),
    );
  }
  
  // Constrói uma seção de resumo (ex: "Armas"), mas só se a lista não estiver vazia
  Widget _buildSectionResumo<T>({
    required String titulo,
    required List<T> lista,
    required List<Widget> Function(T item) builder,
  }) {
    if (lista.isEmpty) {
      return SizedBox.shrink(); // Não mostra a seção se a lista estiver vazia
    }
    
    return Padding(
      padding: const EdgeInsets.only(top: 8.0, bottom: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(titulo, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          SizedBox(height: 8),
          // Para cada item na lista, cria um card
          ...lista.map((item) {
            return _buildItemCard(builder(item)); // Chama a função builder
          }),
        ],
      ),
    );
  }

  // Constrói o Resumo da Etapa 1 (Dados do Fato)
  Widget _buildResumoEtapa1() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Etapa 1: Dados do Fato', style: Theme.of(context).textTheme.titleLarge),
            Divider(height: 20),
            _buildLinhaInfo('Nº Atendimento:', widget.dadosEtapa1['numAtendimento']),
            _buildLinhaInfo('Tipo do ROP:', widget.dadosEtapa1['ropType']),
            _buildLinhaInfo('Cidade:', widget.dadosEtapa1['city']),
            _buildLinhaInfo('Bairro:', widget.dadosEtapa1['bairro']),
            _buildLinhaInfo('Logradouro:', widget.dadosEtapa1['logradouro']),
            _buildLinhaInfo('Número:', widget.dadosEtapa1['numero']),
            _buildLinhaInfo('Data:', widget.dadosEtapa1['data']),
            _buildLinhaInfo('Hora:', widget.dadosEtapa1['hora']),
          ],
        ),
      ),
    );
  }

  // ---
  // --- MUDANÇA PRINCIPAL: Mostra todos os campos de cada item ---
  // ---
  Widget _buildResumoEtapa2() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Etapa 2: Detalhamento', style: Theme.of(context).textTheme.titleLarge),
            Divider(height: 20),

            // Seção Policiais
            _buildSectionResumo<Policial>(
              titulo: 'Policiais Envolvidos (${widget.policiais.length})',
              lista: widget.policiais,
              builder: (policial) => [ 
                _buildLinhaInfo('Nome', policial.nome),
                _buildLinhaInfo('Matrícula', policial.matricula),
                _buildLinhaInfo('Função', policial.funcao),
              ],
            ),

            // Seção Indivíduos
            _buildSectionResumo<Individuo>(
              titulo: 'Indivíduos Envolvidos (${widget.individuos.length})',
              lista: widget.individuos,
              builder: (ind) {
                  // Converte 'true'/'false' em 'Sim'/'Não'
                  String simNao(String? value) => (value == 'true') ? 'Sim' : 'Não';
                  return [
                    _buildLinhaInfo('Envolvimento', ind.tipoEnvolvimento),
                    _buildLinhaInfo('Nome', ind.nome),
                    _buildLinhaInfo('Apelido', ind.apelido),
                    _buildLinhaInfo('CPF', ind.cpf),
                    _buildLinhaInfo('RG', ind.rg),
                    _buildLinhaInfo('Nascimento', ind.dataNascimento),
                    _buildLinhaInfo('Sexo', ind.sexo),
                    _buildLinhaInfo('Nacionalidade', ind.nacionalidade),
                    _buildLinhaInfo('Profissão', ind.profissao),
                    _buildLinhaInfo('Mãe', ind.nomeMae),
                    _buildLinhaInfo('Pai', ind.nomePai),
                    _buildLinhaInfo('Email', ind.email),
                    _buildLinhaInfo('Telefone', ind.telefone),
                    _buildLinhaInfo('CEP', ind.cep),
                    _buildLinhaInfo('Logradouro', ind.logradouro),
                    _buildLinhaInfo('Número', ind.numero),
                    _buildLinhaInfo('Complemento', ind.complemento),
                    _buildLinhaInfo('Cidade', ind.cidade),
                    _buildLinhaInfo('Bairro', ind.bairro),
                    _buildLinhaInfo('Detenção', ind.tipoDetencao),
                    _buildLinhaInfo('Ferido?', simNao(ind.ferido)),
                    _buildLinhaInfo('Usou Algema?', simNao(ind.houveAlgema)),
                    _buildLinhaInfo('Histórico', ind.historico),
                  ];
              }
            ),
            
            // Seção Armas
            _buildSectionResumo<Arma>(
              titulo: 'Armas Apreendidas (${widget.armas.length})',
              lista: widget.armas,
              builder: (arma) => [
                _buildLinhaInfo('Tipo', arma.tipo),
                _buildLinhaInfo('Marca', arma.marca),
                _buildLinhaInfo('Modelo', arma.modelo),
                _buildLinhaInfo('Nº Série', arma.numeroSerie),
                _buildLinhaInfo('Calibre', arma.calibre),
                _buildLinhaInfo('Munições', arma.qtdMunicoes),
                _buildLinhaInfo('Obs.', arma.observacoes),
              ],
            ),

            // Seção Munições
            _buildSectionResumo<Municao>(
              titulo: 'Munições Apreendidas (${widget.municoes.length})',
              lista: widget.municoes,
              builder: (municao) => [
                _buildLinhaInfo('Tipo', municao.tipo),
                _buildLinhaInfo('Quantidade', municao.quantidade),
                _buildLinhaInfo('Obs.', municao.informacoes),
              ],
            ),
            
            // Seção Dinheiro
            _buildSectionResumo<Dinheiro>(
              titulo: 'Dinheiro Apreendido (${widget.dinheiro.length})',
              lista: widget.dinheiro,
              builder: (dinheiro) => [
                _buildLinhaInfo('Valor', dinheiro.valor),
                _buildLinhaInfo('Moeda', dinheiro.moeda),
                _buildLinhaInfo('Obs.', dinheiro.observacoes),
              ],
            ),
            
            // Seção Drogas
            _buildSectionResumo<Drogas>(
              titulo: 'Drogas Apreendidas (${widget.drogas.length})',
              lista: widget.drogas,
              builder: (droga) => [
                _buildLinhaInfo('Tipo', droga.tipo),
                _buildLinhaInfo('Quantidade', '${droga.quantidade ?? ""} ${droga.unidade ?? ""}'),
                _buildLinhaInfo('Apresentação', droga.apresentacao),
                _buildLinhaInfo('Embalagem', droga.embalagem),
              ],
            ),
            
            // Seção Veículos
            _buildSectionResumo<Veiculo>(
              titulo: 'Veículos Apreendidos (${widget.veiculos.length})',
              lista: widget.veiculos,
              builder: (veiculo) => [
                _buildLinhaInfo('Placa', veiculo.placa),
                _buildLinhaInfo('Modelo', veiculo.modelo),
                _buildLinhaInfo('Cor', veiculo.cor),
                _buildLinhaInfo('Chassi', veiculo.chassi),
                _buildLinhaInfo('Espécie', veiculo.especie),
                _buildLinhaInfo('Tipo', veiculo.tipoVeiculo),
                _buildLinhaInfo('Restrição?', veiculo.restricao == 'sim' ? 'Sim' : 'Não'),
              ],
            ),
            
            // Seção Objetos
            _buildSectionResumo<Objeto>(
              titulo: 'Objetos Apreendidos (${widget.objetos.length})',
              lista: widget.objetos,
              builder: (objeto) => [
                _buildLinhaInfo('Tipo', objeto.tipo),
                _buildLinhaInfo('Nome', objeto.nome),
                _buildLinhaInfo('IMEI', objeto.imei),
                _buildLinhaInfo('ID ROP', objeto.idRop),
              ],
            ),

            // Seção Histórico (só aparece se preenchido)
            if (widget.historicoEtapa2.isNotEmpty) ...[
              SizedBox(height: 16),
              Text('Histórico da Ocorrência', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(widget.historicoEtapa2),
              ),
            ]
          ],
        ),
      ),
    );
  }

  // --- Widgets da Etapa 3 (Sem mudanças) ---

  // Dropdown de Destinatário
  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required String hint,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        SizedBox(height: 8),
        DropdownButtonFormField<String>(
          initialValue: value,
          hint: Text(hint),
          isExpanded: true,
          items: items.map((String item) {
            return DropdownMenuItem<String>(
              value: item,
              child: Text(item, overflow: TextOverflow.ellipsis),
            );
          }).toList(),
          onChanged: onChanged,
          decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          ),
        ),
      ],
    );
  }

  // Botões de Ação
  Widget _buildActionButtons() {
    return Row(
      children: [
        // 1. Botão Voltar (Editar)
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              // Ação de "Editar" é simplesmente voltar para a Etapa 2
              Navigator.of(context).pop();
            },
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12),
              side: BorderSide(color: Colors.grey[700]!),
              foregroundColor: Colors.grey[700],
            ),
            child: const Text('Voltar (Editar)', style: TextStyle(fontSize: 16)),
          ),
        ),
        const SizedBox(width: 16),
        // 2. Botão Finalizar
        Expanded(
          child: ElevatedButton(
            // Habilitado somente se os termos foram aceitos E um destinatário foi selecionado
            onPressed: (_termsAccepted && _selectedDestinatario != null)
                ? () {
                    // Lógica para Finalizar
                    _finalizarRop();
                  }
                : null, // Botão desabilitado
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1a73e8),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            child:
                const Text('Finalizar ROP', style: TextStyle(fontSize: 16)),
          ),
        ),
      ],
    );
  }

  // Ação de finalizar (simulação)
  void _finalizarRop() {
    String protocolo = 'ROP-${DateTime.now().millisecondsSinceEpoch}';
    showDialog(
      context: context,
      barrierDismissible: false, 
      builder: (ctx) => AlertDialog(
        title: Text('Ocorrência Finalizada'),
        content: Text('Sua ocorrência foi registrada com sucesso.\n\nProtocolo: $protocolo'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop(); 
              // Fecha a tela de Revisão E a tela de Relatório
              Navigator.of(context).popUntil((route) => route.isFirst);
            },
            child: Text('OK'),
          )
        ],
      ),
    );
  }
}