// ARQUIVO: lib/individuo.dart

class Individuo {
  // Identificação
  final String? nome;
  final String? apelido;
  final String? cpf;
  final String? rg;
  final String? dataNascimento;
  final String? sexo;
  final String? nacionalidade;
  final String? profissao;
  final String? nomeMae;
  final String? nomePai;
  final String? email;
  final String? telefone;
  // Endereço
  final String? cep;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? cidade;
  final String? bairro;
  // Envolvimento
  final String? tipoEnvolvimento;
  final String? tipoDetencao;
  final String? ferido;
  final String? houveAlgema;
  final String? historico;
  // TODO: Adicionar campos de Natureza

  Individuo({
    this.nome,
    this.apelido,
    this.cpf,
    this.rg,
    this.dataNascimento,
    this.sexo,
    this.nacionalidade,
    this.profissao,
    this.nomeMae,
    this.nomePai,
    this.email,
    this.telefone,
    this.cep,
    this.logradouro,
    this.numero,
    this.complemento,
    this.cidade,
    this.bairro,
    this.tipoEnvolvimento,
    this.tipoDetencao,
    this.ferido,
    this.houveAlgema,
    this.historico,
  });
}