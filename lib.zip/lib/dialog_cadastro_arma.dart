import 'package:flutter/material.dart';
import 'arma.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroArma extends StatefulWidget {
  const DialogCadastroArma({super.key});

  @override
  State<DialogCadastroArma> createState() => _DialogCadastroArmaState();
}

class _DialogCadastroArmaState extends State<DialogCadastroArma> {
  final TextEditingController _marcaController = TextEditingController();
  final TextEditingController _modeloController = TextEditingController();
  final TextEditingController _numSerieController = TextEditingController();
  final TextEditingController _qtdMunicoesController = TextEditingController();
  final TextEditingController _calibreController = TextEditingController();
  final TextEditingController _obsController = TextEditingController();
  String? _selectedTipoArma;
  final List<String> _tiposDeArma = ['Pistola', 'Revólver', 'Espingarda', 'Rifle', 'Outros'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Cadastro - Armas Apreendidas'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDropdown(
                label: 'Tipo de Arma:',
                value: _selectedTipoArma,
                items: _tiposDeArma,
                onChanged: (value) {
                  setState(() {
                    _selectedTipoArma = value;
                  });
                },
              ),
              _buildTextField(label: 'Marca:', controller: _marcaController, hint: 'Ex.: Taurus, Glock'),
              _buildTextField(label: 'Modelo:', controller: _modeloController, hint: 'Ex.: PT 938, G2c'),
              _buildTextField(label: 'Número de Série:', controller: _numSerieController, hint: 'Ex.: ABC12345'),
              _buildTextField(label: 'Quantidade de Munições:', controller: _qtdMunicoesController, hint: 'Ex.: 12', keyboardType: TextInputType.number),
              _buildTextField(label: 'Calibre:', controller: _calibreController, hint: 'Ex.: .380, 9mm'),
              _buildTextField(label: 'Observações:', controller: _obsController, hint: 'Ex.: Arma encontrada...', maxLines: 5),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novaArma = Arma(
              tipo: _selectedTipoArma,
              marca: _marcaController.text,
              modelo: _modeloController.text,
              numeroSerie: _numSerieController.text,
              qtdMunicoes: _qtdMunicoesController.text,
              calibre: _calibreController.text,
              observacoes: _obsController.text,
            );
            Navigator.of(context).pop(novaArma);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar Arma'),
        ),
      ],
    );
  }

  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required List<String> items, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          hintText: 'Selecione o tipo',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10),
        ),
      ),
    );
  }
}