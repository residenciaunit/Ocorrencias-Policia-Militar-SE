// ARQUIVO: lib/dinheiro.dart
// (Define o que é um 'Dinheiro')

class Dinheiro {
  final String? moeda;
  final String? valor;
  final String? observacoes;

  Dinheiro({
    this.moeda,
    this.valor,
    this.observacoes,
  });
}