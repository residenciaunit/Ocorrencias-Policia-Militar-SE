import 'package:flutter/material.dart';
import 'municao.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroMunicao extends StatefulWidget {
  const DialogCadastroMunicao({super.key});

  @override
  State<DialogCadastroMunicao> createState() => _DialogCadastroMunicaoState();
}

class _DialogCadastroMunicaoState extends State<DialogCadastroMunicao> {
  final TextEditingController _tipoController = TextEditingController();
  final TextEditingController _quantidadeController = TextEditingController();
  final TextEditingController _informacoesController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Cadastro de Munições'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextField(label: 'Tipo:', controller: _tipoController, hint: 'Ex.: 9mm, .38, .40'),
              _buildTextField(label: 'Quantidade:', controller: _quantidadeController, hint: 'Ex.: 10', keyboardType: TextInputType.number),
              _buildTextField(label: 'Informações da apreensão:', controller: _informacoesController, hint: 'Descreva as informações...', maxLines: 4),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novaMunicao = Municao(
              tipo: _tipoController.text,
              quantidade: _quantidadeController.text,
              informacoes: _informacoesController.text,
            );
            Navigator.of(context).pop(novaMunicao);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar'), 
        ),
      ],
    );
  }

  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    );
  }
}