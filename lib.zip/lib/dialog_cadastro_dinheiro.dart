import 'package:flutter/material.dart';
import 'dinheiro.dart'; 
// ignore_for_file: prefer_const_constructors

class DialogCadastroDinheiro extends StatefulWidget {
  const DialogCadastroDinheiro({super.key});

  @override
  State<DialogCadastroDinheiro> createState() => _DialogCadastroDinheiroState();
}

class _DialogCadastroDinheiroState extends State<DialogCadastroDinheiro> {
  final TextEditingController _valorController = TextEditingController();
  final TextEditingController _obsController = TextEditingController();
  String? _selectedMoeda;
  final List<String> _moedas = ['Real (BRL)', 'Dólar Americano (USD)', 'Euro (EUR)', 'Libra Esterlina (GBP)'];

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Cadastro - Dinheiro Apreendido'),
      content: SingleChildScrollView(
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.9,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDropdown(
                label: 'Moeda:',
                value: _selectedMoeda,
                items: _moedas,
                onChanged: (value) {
                  setState(() {
                    _selectedMoeda = value;
                  });
                },
              ),
              _buildTextField(
                  label: 'Valor Apreendido:',
                  controller: _valorController,
                  hint: 'Ex.: 1500.00',
                  keyboardType: TextInputType.numberWithOptions(decimal: true)),
              _buildTextField(
                  label: 'Observações:',
                  controller: _obsController,
                  hint: 'Ex.: Notas de RS 100 encontradas...',
                  maxLines: 5),
            ],
          ),
        ),
      ),
      actions: [
        OutlinedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancelar'),
        ),
        ElevatedButton(
          onPressed: () {
            final novoDinheiro = Dinheiro(
              moeda: _selectedMoeda,
              valor: _valorController.text,
              observacoes: _obsController.text,
            );
            Navigator.of(context).pop(novoDinheiro);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF1a73e8),
            foregroundColor: Colors.white,
          ),
          child: Text('Salvar'),
        ),
      ],
    );
  }

  Widget _buildTextField({required String label, required TextEditingController controller, String? hint, TextInputType? keyboardType, int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        ),
      ),
    );
  }
  Widget _buildDropdown({required String label, required String? value, required List<String> items, required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        items: items.map((String item) {
          return DropdownMenuItem<String>(
            value: item,
            child: Text(item),
          );
        }).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          hintText: 'Selecione a moeda',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(6)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 10),
        ),
      ),
    );
  }
}