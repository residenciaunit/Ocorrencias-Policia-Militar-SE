document.addEventListener("DOMContentLoaded", function () {
    const cidadeSelect = document.getElementById("fk_cidade");
    const bairroSelect = document.getElementById("bairro");
    const cpfInput = document.getElementById("cpf");
    const cepInput = document.getElementById("cep");
    const telefoneInput = document.getElementById("telefone");
    const dataNascimentoInput = document.getElementById("dataNascimento");
    const btnVoltar = document.getElementById("voltar");


    // --- Lógica para Cidades e Bairros (reaproveitada da etapa 1) ---
    const bairrosPorCidade = {
        "Aracaju": [
            "Atalaia", "Coroa do Meio", "Farolândia", "Aruana", "Jardins", "Salgado Filho", "São José", "Suíssa", "Centro", "13 de Julho", "Getúlio Vargas", "Cirurgia", "Pereira Lobo", "Dezoito do Forte", "Novo Paraíso", "Luzia", "Olaria", "Palestina", "Bugio", "Industrial", "Cidade Nova", "América", "Capucho", "Siqueira Campos", "São Conrado", "Jabotiana", "Santa Maria", "Aeroporto", "Porto Dantas", "Grageru", "Inácio Barbosa", "Marivan", "Ponto Novo", "Lamarão", "José Conrado de Araújo"
        ],
        "Itabaiana": ["Anízio Amancio de Oliveira", "Área Rural de Itabaiana", "Bananeiras", "Centro", "Doutor José Milton Machado", "Mamede Paes Mendonça", "Marcela", "Marianga", "Miguel Teles de Mendonça", "Oviedo Teixeira", "Porto", "Queimadas", "Riacho Doce", "Rotary Club de Itabaiana", "São Cristóvão", "Serrano"],
        "Lagarto": ["Centro"],
        "Nossa Senhora do Socorro": ["Albano Franco", "Boa Viagem", "Castelo", "Centro Histórico", "Fernando Collor", "Guajará", "Itacanema", "Jardim", "João Alves", "Mangabeira", "Marcos Freire I", "Marcos Freire II", "Marcos Freire III", "Novo Horizonte", "Pai André", "Palestina de Dentro", "Palestina de Fora", "Parque dos Faróis", "Piabeta", "Porto Grande", "Santa Cecília", "Santa Inês", "Santo Inácio", "São Brás", "Sobrado", "Taboca", "Taiçoca de Dentro", "Taiçoca de Fora"],
        "São Cristóvão": ["Centro", "Rosa Elze"],
        "Estância": ["Alagoas", "Centro", "Cidade Nova"],
        "Propriá": ["Centro"],
        "Tobias Barreto": ["Centro"],
        "Itaporanga D'Ajuda": ["Centro"]
    };

    function carregarCidadesDeSergipe() {
        cidadeSelect.innerHTML = '<option value="">Selecione a Cidade</option>';
        Object.keys(bairrosPorCidade).forEach(cidade => {
            const option = document.createElement("option");
            option.value = cidade; // O ideal seria um ID (fk_cidade)
            option.textContent = cidade;
            cidadeSelect.appendChild(option);
        });
    }

    carregarCidadesDeSergipe();

    cidadeSelect.addEventListener("change", function () {
        bairroSelect.innerHTML = '<option value="">Selecione o Bairro</option>';
        const cidadeSelecionada = cidadeSelect.value;
        const bairros = bairrosPorCidade[cidadeSelecionada] || [];

        bairros.forEach(bairro => {
            const option = document.createElement("option");
            option.value = bairro;
            option.textContent = bairro;
            bairroSelect.appendChild(option);
        });
    });

    // --- Validação da Data de Nascimento ---
    function validarDataNascimento() {
        const dataCampo = dataNascimentoInput.value;
        const hoje = new Date().toISOString().split('T')[0];
        if (dataCampo && dataCampo > hoje) {
            alert("A data de nascimento não pode ser uma data futura.");
            dataNascimentoInput.value = "";
        }
    }

    dataNascimentoInput.addEventListener("input", validarDataNascimento);

    // --- Máscaras de Formulário ---
    function formatCPF(cpf) {
        cpf = cpf.replace(/\D/g, ""); // Remove tudo que não é dígito
        cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2");
        cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2");
        cpf = cpf.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
        return cpf;
    }

    function formatCEP(cep) {
        cep = cep.replace(/\D/g, "");
        cep = cep.replace(/^(\d{5})(\d)/, "$1-$2");
        return cep;
    }

    function formatTelefone(telefone) {
        telefone = telefone.replace(/\D/g, "");
        telefone = telefone.replace(/^(\d{2})(\d)/g, "($1) $2");
        telefone = telefone.replace(/(\d)(\d{4})$/, "$1-$2");
        return telefone;
    }

    cpfInput.addEventListener('input', (e) => {
        e.target.value = formatCPF(e.target.value);
    });

    cepInput.addEventListener('input', (e) => {
        e.target.value = formatCEP(e.target.value);
    });

    telefoneInput.addEventListener('input', (e) => {
        e.target.value = formatTelefone(e.target.value);
    });
    
    // --- Navegação ---
    btnVoltar.addEventListener('click', () => {
        // Redireciona para a página principal. Altere 'index.html' se o nome for outro.
        window.location.href = 'index.html'; 
    });

});