document.addEventListener("DOMContentLoaded", function () {
    const accordionHeaders = document.querySelectorAll(".accordion-header");
    const btnVoltar = document.getElementById("voltar");

    // --- Lógica para o botão Voltar ---
    btnVoltar.addEventListener('click', () => {
        // Redireciona para a página de cadastro inicial
        window.location.href = 'index.html'; 
    });

    // --- Lógica para controlar o Accordion ---
    accordionHeaders.forEach(header => {
        header.addEventListener("click", function () {
            this.classList.toggle("active");
            const content = this.nextElementSibling;
            content.classList.toggle("active");

            if (content.style.maxHeight) {
                content.style.maxHeight = null;
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
            }
        });
    });

    // --- Lógica para exibir seções com base na seleção da Etapa 1 ---
    function exibirSecoesSelecionadas() {
        const elementosSelecionadosJSON = sessionStorage.getItem('elementosSelecionados');
        
        if (!elementosSelecionadosJSON) {
            console.warn("Nenhuma seleção da etapa 1 foi encontrada.");
            document.getElementById('secao-individuo').style.display = 'block';
            return;
        }

        const elementos = JSON.parse(elementosSelecionadosJSON);

        elementos.forEach(idElemento => {
            const secao = document.getElementById(`secao-${idElemento}`);
            if (secao) {
                secao.style.display = 'block';
            }
        });
    }

    exibirSecoesSelecionadas();
});