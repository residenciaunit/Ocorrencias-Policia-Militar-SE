document.addEventListener("DOMContentLoaded", function () {
    const cidadeSelect = document.getElementById("cidade");
    const bairroSelect = document.getElementById("bairro");
    const btnProximo = document.getElementById("proximo");
    const elementos = document.querySelectorAll(".elemento-btn");

    // --- Lógica para Cidades e Bairros ---
    const bairrosPorCidade = {
        "Aracaju": [
            "Atalaia", "Coroa do Meio", "Farolândia", "Aruana", "Jardins", "Salgado Filho", "São José", "Suíssa", "Centro", "13 de Julho", "Getúlio Vargas", "Cirurgia", "Pereira Lobo", "Dezoito do Forte", "Novo Paraíso", "Luzia", "Olaria", "Palestina", "Bugio", "Industrial", "Cidade Nova", "América", "Capucho", "Siqueira Campos", "São Conrado", "Jabotiana", "Santa Maria", "Aeroporto", "Porto Dantas", "Grageru", "Inácio Barbosa", "Marivan", "Ponto Novo", "Lamarão", "José Conrado de Araújo"
        ],
        "Itabaiana": [
            "Anízio Amancio de Oliveira", "Área Rural de Itabaiana", "Bananeiras", "Centro", "Doutor José Milton Machado", "Mamede Paes Mendonça", "Marcela", "Marianga", "Miguel Teles de Mendonça", "Oviedo Teixeira", "Porto", "Queimadas", "Riacho Doce", "Rotary Club de Itabaiana", "São Cristóvão", "Serrano"
        ],
        "Lagarto": ["Centro"],
        "Nossa Senhora do Socorro": [
            "Albano Franco", "Boa Viagem", "Castelo", "Centro Histórico", "Fernando Collor", "Guajará", "Itacanema", "Jardim", "João Alves", "Mangabeira", "Marcos Freire I", "Marcos Freire II", "Marcos Freire III", "Novo Horizonte", "Pai André", "Palestina de Dentro", "Palestina de Fora", "Parque dos Faróis", "Piabeta", "Porto Grande", "Santa Cecília", "Santa Inês", "Santo Inácio", "São Brás", "Sobrado", "Taboca", "Taiçoca de Dentro", "Taiçoca de Fora"
        ],
        "São Cristóvão": ["Centro", "Rosa Elze"],
        "Estância": ["Alagoas", "Centro", "Cidade Nova"],
        "Propriá": ["Centro"],
        "Tobias Barreto": ["Centro"],
        "Itaporanga D'Ajuda": ["Centro"]
    };

    function carregarCidadesDeSergipe() {
        cidadeSelect.innerHTML = "";
        Object.keys(bairrosPorCidade).forEach(cidade => {
            const option = document.createElement("option");
            option.value = cidade;
            option.textContent = cidade;
            cidadeSelect.appendChild(option);
        });
    }

    carregarCidadesDeSergipe();

    cidadeSelect.addEventListener("change", function () {
        bairroSelect.innerHTML = "";

        const cidadeSelecionada = cidadeSelect.value;
        const bairros = bairrosPorCidade[cidadeSelecionada] || [];

        bairros.forEach(bairro => {
            const option = document.createElement("option");
            option.value = bairro;
            option.textContent = bairro;
            bairroSelect.appendChild(option);
        });
    });

    // Dispara o evento 'change' inicialmente para carregar os bairros da primeira cidade da lista
    cidadeSelect.dispatchEvent(new Event("change"));

    // --- Lógica para Validação de Data e Hora ---
    function validarData() {
        const dataCampo = document.getElementById("data").value;
        const hoje = new Date().toISOString().split('T')[0];
        if (dataCampo && dataCampo > hoje) {
            alert("A data não pode ser futura.");
            document.getElementById("data").value = hoje;
        }
    }

    document.getElementById("data").addEventListener("input", validarData);

    function validarHora() {
        const dataCampo = document.getElementById("data").value;
        const dataHoje = new Date().toISOString().split('T')[0];

        if (dataCampo === dataHoje) {
            const horaCampo = document.getElementById("hora").value;
            const agora = new Date();
            const horas = agora.getHours().toString().padStart(2, '0');
            const minutos = agora.getMinutes().toString().padStart(2, '0');
            const horaHoje = `${horas}:${minutos}`;

            if (horaCampo > horaHoje) {
                alert("Como a ocorrência foi hoje, a hora não pode ser futura.");
                document.getElementById("hora").value = horaHoje;
            }
        }
    }

    document.getElementById("hora").addEventListener("input", validarHora);

    // --- Lógica para Navegação e Salvamento de Seleções ---

    // Habilita o botão "Próximo" apenas quando pelo menos um elemento está selecionado
    function verificarSelecaoParaProximo() {
        let algumSelecionado = false;
        elementos.forEach(checkbox => {
            if (checkbox.checked) {
                algumSelecionado = true;
            }
        });
        btnProximo.disabled = !algumSelecionado;
    }

    // Adiciona o listener para cada checkbox
    elementos.forEach(checkbox => {
        checkbox.addEventListener('change', verificarSelecaoParaProximo);
    });

    // Evento de clique para o botão "Próximo"
    btnProximo.addEventListener("click", function () {
        // NOVO: Salva todos os dados do formulário no sessionStorage
        const dadosForm = {
            tipo_do_rop: document.getElementById('tipo_do_rop').value,
            cidade: document.getElementById('cidade').value,
            bairro: document.getElementById('bairro').value,
            num_atendimento: document.getElementById('num_atendimento').value,
            destino: document.getElementById('destino').value,
            logradouro: document.getElementById('logradouro').value,
            numero: document.getElementById('numero').value,
            ponto_referencia: document.getElementById('ponto_referencia').value,
            data: document.getElementById('data').value,
            hora: document.getElementById('hora').value,
        };
        sessionStorage.setItem('dadosFormEtapa1', JSON.stringify(dadosForm));


        const selecionados = [];
        elementos.forEach(checkbox => {
            if (checkbox.checked) {
                selecionados.push(checkbox.id); // Salva o ID (ex: 'armas', 'municao')
            }
        });

        if (selecionados.length > 0) {
            // Salva a lista de itens selecionados no sessionStorage para a próxima página usar
            sessionStorage.setItem('elementosSelecionados', JSON.stringify(selecionados));

            // Navega para a próxima página apropriada.
            if (selecionados.includes('individuo')) {
                window.location.href = "individuo.html";
            } else {
                window.location.href = "relatorio.html";
            }
        } else {
            alert("Selecione pelo menos um elemento para cadastrar na ocorrência.");
        }
    });
    
    // NOVO: Função para carregar os dados do formulário do sessionStorage quando a página é carregada
    function carregarDadosSalvos() {
        const dadosSalvosJSON = sessionStorage.getItem('dadosFormEtapa1');
        if (dadosSalvosJSON) {
            const dadosSalvos = JSON.parse(dadosSalvosJSON);

            document.getElementById('tipo_do_rop').value = dadosSalvos.tipo_do_rop;
            document.getElementById('cidade').value = dadosSalvos.cidade;
            
            // Dispara o evento 'change' para carregar a lista de bairros correta
            cidadeSelect.dispatchEvent(new Event('change'));
            
            // Com a lista de bairros atualizada, seleciona o bairro salvo
            document.getElementById('bairro').value = dadosSalvos.bairro;
            
            document.getElementById('num_atendimento').value = dadosSalvos.num_atendimento;
            document.getElementById('destino').value = dadosSalvos.destino;
            document.getElementById('logradouro').value = dadosSalvos.logradouro;
            document.getElementById('numero').value = dadosSalvos.numero;
            document.getElementById('ponto_referencia').value = dadosSalvos.ponto_referencia;
            document.getElementById('data').value = dadosSalvos.data;
            document.getElementById('hora').value = dadosSalvos.hora;
        }

        // Também carrega a seleção dos botões (Dinheiro, Drogas, etc.)
        const elementosSelecionadosJSON = sessionStorage.getItem('elementosSelecionados');
        if(elementosSelecionadosJSON) {
            const elementosSalvos = JSON.parse(elementosSelecionadosJSON);
            elementosSalvos.forEach(idElemento => {
                const checkbox = document.getElementById(idElemento);
                if(checkbox) {
                    checkbox.checked = true;
                }
            });
        }
    }

    // Carrega os dados salvos assim que a página é iniciada
    carregarDadosSalvos();

    // Garante que o estado inicial do botão esteja correto ao carregar a página
    verificarSelecaoParaProximo();
});